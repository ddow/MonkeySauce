__author__ = 'ddow'
"""Parses ALE metadata into searchable and scriptble data.
"""

class Ale_parser:
    """This class parses ALEs and defines methods for reading metadata from them.
    """
    def __init__(self,file):
        self.data = open(file, 'r')
        self.file = file
        #self.name = input('What column name contains the file name? ')

    def keys(self):
        """returns list of keys for ALE file
        """
        for line in open(self.file, 'r'):
            if len(line.strip()) > 40:
                keys = line.strip().split('\t')
                return keys
            continue

    def values(self, value):
        """given any value for one item in ALE, returns all values for item.
        """
        for line in open(self.file, 'r'):
            if value in line:
                values = line.strip().split('\t')
                return values
            continue

    def dict(self, value):
        """given any value for one item i ALE, returns dict of key/value pairs.
        """
        for line in open(self.file, 'r'):
            if value in line:
                values = self.values(value)
                keys = self.keys()
                result = dict()
                for key in keys:
                    try:
                        val = values[keys.index(key)].strip()
                    except IndexError:
                        val = None
                    else:
                        val = values[keys.index(key)].strip()
                    result[key] = val
                return result
            continue

    def get_value(self, value, key):
        """Returns value of key for item specified by value in ALE.
        """
        for line in open(self.file, 'r'):
            if value in line:
                item = self.dict(line)
                return item[key]


"""
test = Ale_parser('204027.ALE')
keys = test.keys()
print(keys)
name = 'A336C005_150130_R6M2'
values = test.values(name)
print(values)
d = test.dict(name)
print(d)
g = test.get_value(name, 'Scene')
print(g)
"""