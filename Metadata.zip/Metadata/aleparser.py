__author__ = 'Daniel Dow for PIX|System'

"""
Parses ALE metadata into indexed data structures.
"""

class AleParser:
    """This class parses ALEs and defines methods
    for reading metadata from them.
    """
    def __init__(self, file):
        """Data structures are self.keys and self.data.
        The data structure self.keys is a list of the
        keys from the ALE.  The data structure self.data
        is a list of the items in the ALE containing a
        list of the metadata values for the item.
        """
        self.data = []
        parse_mode = 'unknown'
        for line in open(file, 'r'):
            # Figure out if we should change our parse mode
            if line == '':
                continue
            if line.strip() == 'Column':
                parse_mode = 'keys'
                continue
            elif line.strip() == 'Data':
                parse_mode = 'data'
                continue
            # Parse the data into keys or a list of items
            if parse_mode == 'keys':
                self.keys = line.strip().split('\t')
                parse_mode = 'unknown'
                continue
            elif parse_mode == 'data':
                item = line.strip().split('\t')
                self.data.append(item)
                continue

    def key_values(self, key=None, value=None):
        """Returns dictionaries of items in Ale_parser
        object.  If no value is specified, all key/value
        pairs for every item in object is returned.  If
        value is given, all key/value pairs for every
        item containing the value is returned.  If key
        is given, only the key value pairs for the
        key specified is returned.
        """
        if not value:
            dicts = [dict(zip(self.keys, line)) for line in self.data]
        else:
            dicts = [dict(zip(self.keys, line)) for line in self.data if value in line]
        if key == None:
            return dicts
        else:
            result = 'Items with ' and value and ' match items with key ' and key and ' ' \
                   and [item[key] for item in dicts]
        return result


test = AleParser('204027.ALE')
d = test.key_values('Filename','4.27D-1')
print(d)